# ANOROC README

Det här är en readme om Anorocs hemsida.

Denna hemsidan utecklades under tiden som det övriga projektet, här kan man enkelt navigera runt och läsa om ANOROCS olika delar. Här hittar ni även vår rapport samt information om oss